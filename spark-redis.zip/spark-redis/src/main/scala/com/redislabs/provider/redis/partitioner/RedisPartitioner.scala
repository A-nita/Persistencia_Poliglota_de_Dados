package com.redislabs.provider.redis.partitioner
