package com.redislabs.provider.redis

package object streaming extends RedisStreamingFunctions {

}
